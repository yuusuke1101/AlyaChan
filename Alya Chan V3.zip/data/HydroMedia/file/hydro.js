{
	"name": "Alya Bot Multi Device "
}